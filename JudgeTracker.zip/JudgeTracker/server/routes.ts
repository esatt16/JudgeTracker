import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProjectSchema, scoreSchema } from "@shared/schema";

export function registerRoutes(app: Express): Server {
  app.get("/api/projects", async (_req, res) => {
    const projects = await storage.getProjects();
    res.json(projects);
  });

  app.post("/api/projects", async (req, res) => {
    const parsed = insertProjectSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error });
      return;
    }

    const project = await storage.createProject(parsed.data);
    res.json(project);
  });

  app.get("/api/projects/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const project = await storage.getProject(id);
    
    if (!project) {
      res.status(404).json({ error: "Project not found" });
      return;
    }
    res.json(project);
  });

  app.get("/api/projects/:id/scores", async (req, res) => {
    const id = parseInt(req.params.id);
    const scores = await storage.getProjectScores(id);
    res.json(scores);
  });

  app.post("/api/scores", async (req, res) => {
    const parsed = scoreSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error });
      return;
    }

    const existingScore = await storage.getJudgeScore(
      parsed.data.projectId,
      parsed.data.judgeId
    );
    if (existingScore) {
      res.status(400).json({ error: "Judge has already scored this project" });
      return;
    }

    const score = await storage.createScore(parsed.data);
    res.json(score);
  });

  app.get("/api/judges", async (_req, res) => {
    const judges = await storage.getJudges();
    res.json(judges);
  });

  app.post("/api/clear-database", async (_req, res) => {
    try {
      await storage.clearDatabase();
      res.json({ message: "Database cleared successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear database" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
