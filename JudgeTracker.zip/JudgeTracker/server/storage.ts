import { type Project, type Score, type Judge, type InsertProject, type InsertScore, type InsertJudge, DEFAULT_CATEGORIES } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";
import { projects, scores, judges } from "@shared/schema";

export interface IStorage {
  // Projects
  getProject(id: number): Promise<Project | undefined>;
  getProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;

  // Scores
  getProjectScores(projectId: number): Promise<Score[]>;
  createScore(score: InsertScore): Promise<Score>;
  getJudgeScore(projectId: number, judgeId: number): Promise<Score | undefined>;

  // Judges
  getJudge(id: number): Promise<Judge | undefined>;
  getJudges(): Promise<Judge[]>;
  createJudge(judge: InsertJudge): Promise<Judge>;
}

export class DatabaseStorage implements IStorage {
  async getProject(id: number): Promise<Project | undefined> {
    try {
      const [project] = await db.select().from(projects).where(eq(projects.id, id));
      if (project) {
        // Ensure categories is an array
        return {
          ...project,
          categories: Array.isArray(project.categories) ? project.categories : DEFAULT_CATEGORIES,
        };
      }
      return undefined;
    } catch (error) {
      console.error('Error getting project:', error);
      throw error;
    }
  }

  async getProjects(): Promise<Project[]> {
    try {
      const projectList = await db.select().from(projects);
      // Ensure categories is an array for each project
      return projectList.map(project => ({
        ...project,
        categories: Array.isArray(project.categories) ? project.categories : DEFAULT_CATEGORIES,
      }));
    } catch (error) {
      console.error('Error getting projects:', error);
      throw error;
    }
  }

  async createProject(project: InsertProject): Promise<Project> {
    try {
      const projectToInsert = {
        ...project,
        categories: Array.isArray(project.categories) ? project.categories : DEFAULT_CATEGORIES,
      };

      const [newProject] = await db.insert(projects).values(projectToInsert).returning();
      return {
        ...newProject,
        categories: Array.isArray(newProject.categories) ? newProject.categories : DEFAULT_CATEGORIES,
      };
    } catch (error) {
      console.error('Error creating project:', error);
      throw error;
    }
  }

  async getProjectScores(projectId: number): Promise<Score[]> {
    try {
      return await db.select().from(scores).where(eq(scores.projectId, projectId));
    } catch (error) {
      console.error('Error getting project scores:', error);
      throw error;
    }
  }

  async createScore(score: InsertScore): Promise<Score> {
    try {
      const [newScore] = await db.insert(scores).values(score).returning();
      return newScore;
    } catch (error) {
      console.error('Error creating score:', error);
      throw error;
    }
  }

  async getJudgeScore(projectId: number, judgeId: number): Promise<Score | undefined> {
    try {
      const [score] = await db
        .select()
        .from(scores)
        .where(
          and(
            eq(scores.projectId, projectId),
            eq(scores.judgeId, judgeId)
          )
        );
      return score;
    } catch (error) {
      console.error('Error getting judge score:', error);
      throw error;
    }
  }

  async getJudge(id: number): Promise<Judge | undefined> {
    try {
      const [judge] = await db.select().from(judges).where(eq(judges.id, id));
      return judge;
    } catch (error) {
      console.error('Error getting judge:', error);
      throw error;
    }
  }

  async getJudges(): Promise<Judge[]> {
    try {
      const existingJudges = await db.select().from(judges);
      if (existingJudges.length === 0) {
        // Add default judges if none exist
        const defaultJudges = [];
        for (let i = 1; i <= 5; i++) {
          const [judge] = await db
            .insert(judges)
            .values({ name: `Judge ${i}` })
            .returning();
          defaultJudges.push(judge);
        }
        return defaultJudges;
      }
      return existingJudges;
    } catch (error) {
      console.error('Error getting judges:', error);
      throw error;
    }
  }

  async createJudge(judge: InsertJudge): Promise<Judge> {
    try {
      const [newJudge] = await db.insert(judges).values(judge).returning();
      return newJudge;
    } catch (error) {
      console.error('Error creating judge:', error);
      throw error;
    }
  }

  async clearDatabase(): Promise<void> {
    try {
      // Delete all data in reverse dependency order
      await db.delete(scores);
      await db.delete(projects);
      await db.delete(judges);
      
      // Create exactly 5 judges
      for (let i = 1; i <= 5; i++) {
        await this.createJudge({ name: `Judge ${i}` });
      }
    } catch (error) {
      console.error('Error clearing database:', error);
      throw error;
    }
  }
}

export const storage = new DatabaseStorage();