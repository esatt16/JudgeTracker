import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Score, Project } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import type { Judge } from "@shared/schema";

interface ScoreDisplayProps {
  project: Project;
  scores: Score[];
}

export default function ScoreDisplay({ project, scores }: ScoreDisplayProps) {
  const { data: judges } = useQuery<Judge[]>({
    queryKey: ["/api/judges"],
    staleTime: 0,
    refetchOnMount: true,
    refetchInterval: 1000
  });

  const calculateAverages = () => {
    if (!project.categories || !Array.isArray(project.categories)) {
      return [];
    }
    const totals = Array(project.categories.length).fill(0);
    scores.forEach((score) => {
      if (Array.isArray(score.scores)) {
        score.scores.forEach((val, idx) => {
          totals[idx] += val;
        });
      }
    });
    return totals.map(total => (total / scores.length) || 0);
  };

  const averages = calculateAverages();
  const overallAverage = averages.length > 0 
    ? averages.reduce((a, b) => a + b, 0) / averages.length 
    : 0;

  return (
    <div className="space-y-6">
      {/* Individual Judge Scores */}
      {scores.map((score) => {
        const judge = judges?.find(j => j.id === score.judgeId);
        return (
          <Card key={score.id} className="border-l-4 border-l-primary">
            <CardHeader>
              <h4 className="text-lg font-semibold">
                {judge ? judge.name : "Judge"}'s Evaluation
              </h4>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Individual Category Scores */}
                {project.categories && Array.isArray(project.categories) && (
                  <div className="grid gap-2">
                    {project.categories.map((category, idx) => (
                      <div key={idx} className="flex justify-between items-center">
                        <span className="text-sm font-medium">{category}</span>
                        <span className="text-sm">
                          {score?.scores?.[idx] ? `${score.scores[idx]}/5` : 'N/A'}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
                {/* Judge's Comment */}
                <div className="pt-4 border-t">
                  <p className="text-sm text-muted-foreground italic">
                    "{score?.comment || 'No comment provided'}"
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}

      {/* Overall Averages */}
      <Card className="bg-muted/50">
        <CardHeader>
          <h3 className="text-lg font-semibold">Overall Scores</h3>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {project.categories && Array.isArray(project.categories) && (
              <div className="grid gap-2">
                {project.categories.map((category, idx) => (
                  <div key={idx} className="flex justify-between items-center">
                    <span className="font-medium">{category}</span>
                    <span className="font-semibold">{averages[idx]?.toFixed(2) || '0.00'}/5</span>
                  </div>
                ))}
              </div>
            )}
            <div className="pt-4 border-t">
              <div className="flex justify-between items-center">
                <span className="font-bold">Final Score</span>
                <span className="font-bold text-lg">{overallAverage.toFixed(2)}/5</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}