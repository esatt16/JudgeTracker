import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function NavHeader() {
  const { toast } = useToast();

  const clearMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/clear-database");
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Database cleared",
        description: "All judging data has been reset.",
      });
      queryClient.invalidateQueries();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <header className="border-b">
      <nav className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <h1 className="text-xl font-bold">Project Judging Platform</h1>
          <Link href="/">
            <Button variant="ghost">Team View</Button>
          </Link>
          <Link href="/judge">
            <Button variant="ghost">Judge Dashboard</Button>
          </Link>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/projects/new">
            <Button>New Project</Button>
          </Link>
          <Button
            variant="outline"
            size="sm"
            onClick={() => clearMutation.mutate()}
            disabled={clearMutation.isPending}
          >
            Clear Database
          </Button>
        </div>
      </nav>
    </header>
  );
}