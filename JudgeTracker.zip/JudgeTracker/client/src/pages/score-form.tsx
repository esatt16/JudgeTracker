import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { scoreSchema, DEFAULT_CATEGORIES } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Project, Judge } from "@shared/schema";

export default function ScoreForm({
  params: { id },
}: {
  params: { id: string };
}) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const projectId = parseInt(id);

  const { data: project, isLoading: projectLoading } = useQuery<Project>({
    queryKey: ["/api/projects", projectId],
  });

  const { data: judges, isLoading: judgesLoading } = useQuery<Judge[]>({
    queryKey: ["/api/judges"],
  });

  const categories = project?.categories || DEFAULT_CATEGORIES;

  const form = useForm({
    resolver: zodResolver(scoreSchema),
    defaultValues: {
      projectId,
      judgeId: undefined,
      scores: Array(categories.length).fill(3),
      comment: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (values: any) => {
      const res = await apiRequest("POST", "/api/scores", values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Score submitted",
        description: "Your scores have been recorded successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "scores"] });
      navigate("/judge");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (projectLoading || judgesLoading) {
    return (
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">Loading...</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center text-destructive">Project not found</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <h2 className="text-2xl font-bold">Score Project: {project.name}</h2>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit((data) => mutation.mutate(data))}
              className="space-y-6"
            >
              <FormField
                control={form.control}
                name="judgeId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Judge</FormLabel>
                    <Select
                      onValueChange={(value) => field.onChange(parseInt(value))}
                      value={field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a judge" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {judges?.map((judge) => (
                          <SelectItem
                            key={judge.id}
                            value={judge.id.toString()}
                          >
                            {judge.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {categories.map((category, index) => (
                <FormField
                  key={index}
                  control={form.control}
                  name={`scores.${index}`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {category} (Score: {field.value})
                      </FormLabel>
                      <FormControl>
                        <Slider
                          min={1}
                          max={5}
                          step={1}
                          value={[field.value]}
                          onValueChange={(values) => field.onChange(values[0])}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              ))}

              <FormField
                control={form.control}
                name="comment"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Comment</FormLabel>
                    <FormControl>
                      <Textarea {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button type="submit" disabled={mutation.isPending}>
                Submit Scores
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}