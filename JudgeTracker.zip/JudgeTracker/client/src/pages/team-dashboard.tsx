import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import ScoreDisplay from "@/components/score-display";
import type { Project, Score } from "@shared/schema";

export default function TeamDashboard() {
  const { data: projects, isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  if (projectsLoading) {
    return <div>Loading projects...</div>;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold">Team Dashboard</h2>
      <div className="grid gap-6">
        {projects?.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>
    </div>
  );
}

function ProjectCard({ project }: { project: Project }) {
  const { data: scores } = useQuery<Score[]>({
    queryKey: ["/api/projects", project.id, "scores"],
    enabled: !!project.id,
    refetchInterval: 1000
  });

  return (
    <Card>
      <CardHeader>
        <h3 className="text-2xl font-semibold">{project.name}</h3>
        <p className="text-sm text-muted-foreground">{project.description}</p>
      </CardHeader>
      <CardContent>
        {scores && scores.length > 0 ? (
          <ScoreDisplay project={project} scores={scores} />
        ) : (
          <p className="text-muted-foreground">No scores yet</p>
        )}
      </CardContent>
    </Card>
  );
}
