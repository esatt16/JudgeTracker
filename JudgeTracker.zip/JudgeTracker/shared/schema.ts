import { pgTable, text, serial, integer, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const DEFAULT_CATEGORIES = ['Innovation', 'Technical Complexity', 'Design', 'Presentation', 'Impact'] as const;

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  categories: json("categories").$type<string[]>().notNull().default(DEFAULT_CATEGORIES),
});

export const scores = pgTable("scores", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  judgeId: integer("judge_id").notNull(),
  scores: json("scores").$type<number[]>().notNull(),
  comment: text("comment").notNull(),
});

export const judges = pgTable("judges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
});

export const insertProjectSchema = createInsertSchema(projects).extend({
  categories: z.array(z.string()).default(DEFAULT_CATEGORIES),
});

export const scoreSchema = z.object({
  projectId: z.number(),
  judgeId: z.number(),
  scores: z.array(z.number().min(1).max(5)),
  comment: z.string().min(1),
});

export const insertJudgeSchema = createInsertSchema(judges).pick({
  name: true,
});

export type Project = typeof projects.$inferSelect;
export type Score = typeof scores.$inferSelect;
export type Judge = typeof judges.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type InsertScore = z.infer<typeof scoreSchema>;
export type InsertJudge = z.infer<typeof insertJudgeSchema>;